"""SQLite persistence for Yalla Qom Zaker."""
from __future__ import annotations

import os
import shutil
import sqlite3
import sys
import tempfile
import threading
from contextlib import contextmanager
from datetime import datetime

_LOCK = threading.RLock()


def database_path() -> str:
    """Return a persistent app database path without touching protected folders at import time."""
    if sys.platform == "emscripten" or os.environ.get("PYODIDE"):
        return ":memory:"
    if os.name == "nt":
        root = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    else:
        root = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(root, "yalla_qom_zaker", "study.sqlite3")


_DB_PATH = database_path()
_MEMORY_CONNECTION: sqlite3.Connection | None = None


def set_database_directory(directory: str) -> None:
    """Use Flet's app-private support directory on installed mobile and desktop apps."""
    global _DB_PATH
    if _DB_PATH == ":memory:":
        return
    _DB_PATH = os.path.join(directory, "yalla_qom_zaker", "study.sqlite3")


def data_directory() -> str:
    """Return the private folder used for the database and imported audio files."""
    if _DB_PATH == ":memory:":
        return tempfile.gettempdir()
    return os.path.dirname(_DB_PATH)


def _connect() -> sqlite3.Connection:
    global _MEMORY_CONNECTION, _DB_PATH
    if _DB_PATH == ":memory:":
        if _MEMORY_CONNECTION is None:
            _MEMORY_CONNECTION = sqlite3.connect(":memory:", check_same_thread=False)
            _MEMORY_CONNECTION.row_factory = sqlite3.Row
            _MEMORY_CONNECTION.execute("PRAGMA foreign_keys = ON")
        return _MEMORY_CONNECTION
    try:
        os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
    except OSError:
        # Fallback for runtimes whose HOME points at a protected system directory.
        fallback = os.path.join(tempfile.gettempdir(), "yalla_qom_zaker", "study.sqlite3")
        os.makedirs(os.path.dirname(fallback), exist_ok=True)
        _DB_PATH = fallback
    connection = sqlite3.connect(_DB_PATH, timeout=15)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def init_db() -> None:
    with _LOCK, _connection() as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS subjects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                color TEXT NOT NULL DEFAULT 'BLUE',
                weekly_goal INTEGER NOT NULL DEFAULT 0,
                total_minutes INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
                minutes INTEGER NOT NULL,
                session_type TEXT NOT NULL DEFAULT 'study',
                started_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
                title TEXT NOT NULL,
                done INTEGER NOT NULL DEFAULT 0,
                due_date TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS alarms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                label TEXT NOT NULL,
                time TEXT NOT NULL,
                days TEXT NOT NULL DEFAULT 'all',
                enabled INTEGER NOT NULL DEFAULT 1,
                ringtone TEXT NOT NULL DEFAULT '',
                subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS ringtones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                path TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target_minutes_daily INTEGER NOT NULL DEFAULT 120,
                target_minutes_weekly INTEGER NOT NULL DEFAULT 840,
                active INTEGER NOT NULL DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            INSERT INTO goals (target_minutes_daily, target_minutes_weekly, active)
                SELECT 120, 840, 1 WHERE NOT EXISTS (SELECT 1 FROM goals);
            """
        )
        # Older databases may not yet have subject associations on alarms.
        columns = {row["name"] for row in connection.execute("PRAGMA table_info(alarms)")}
        if "subject_id" not in columns:
            connection.execute("ALTER TABLE alarms ADD COLUMN subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL")


@contextmanager
def _connection():
    connection = _connect()
    try:
        with connection:
            yield connection
    finally:
        if _DB_PATH != ":memory:":
            connection.close()


def _rows(sql: str, params: tuple = ()) -> list[dict]:
    with _LOCK, _connection() as connection:
        return [dict(row) for row in connection.execute(sql, params).fetchall()]


def _one(sql: str, params: tuple = ()) -> dict | None:
    rows = _rows(sql, params)
    return rows[0] if rows else None


def _write(sql: str, params: tuple = ()) -> int:
    with _LOCK, _connection() as connection:
        cursor = connection.execute(sql, params)
        return int(cursor.lastrowid or 0)


def list_subjects() -> list[dict]:
    return _rows("SELECT * FROM subjects ORDER BY name COLLATE NOCASE")


def save_subject(name: str, color: str, weekly_goal: int, subject_id: int | None = None) -> int:
    if subject_id:
        _write("UPDATE subjects SET name=?, color=?, weekly_goal=? WHERE id=?", (name, color, weekly_goal, subject_id))
        return subject_id
    return _write("INSERT INTO subjects(name,color,weekly_goal) VALUES(?,?,?)", (name, color, weekly_goal))


def delete_subject(subject_id: int) -> None:
    _write("DELETE FROM subjects WHERE id=?", (subject_id,))


def list_tasks() -> list[dict]:
    return _rows("""SELECT tasks.*, subjects.name AS subject_name, subjects.color AS subject_color
                    FROM tasks LEFT JOIN subjects ON subjects.id=tasks.subject_id
                    ORDER BY done ASC, due_date ASC, id DESC""")


def save_task(title: str, due_date: str, subject_id: int | None = None) -> int:
    return _write("INSERT INTO tasks(subject_id,title,due_date,created_at) VALUES(?,?,?,?)",
                  (subject_id, title, due_date, datetime.now().isoformat(timespec="seconds")))


def set_task_done(task_id: int, done: bool) -> None:
    _write("UPDATE tasks SET done=? WHERE id=?", (int(done), task_id))


def delete_task(task_id: int) -> None:
    _write("DELETE FROM tasks WHERE id=?", (task_id,))


def add_session(subject_id: int | None, minutes: int, session_type: str = "study", started_at: str | None = None) -> int:
    started_at = started_at or datetime.now().isoformat(timespec="seconds")
    with _LOCK, _connection() as connection:
        cursor = connection.execute(
            "INSERT INTO sessions(subject_id,minutes,session_type,started_at) VALUES(?,?,?,?)",
            (subject_id, minutes, session_type, started_at),
        )
        if subject_id is not None:
            connection.execute("UPDATE subjects SET total_minutes=total_minutes+? WHERE id=?", (minutes, subject_id))
        return int(cursor.lastrowid or 0)


def session_rows() -> list[dict]:
    return _rows("""SELECT sessions.*, subjects.name AS subject_name, subjects.color AS subject_color
                    FROM sessions LEFT JOIN subjects ON subjects.id=sessions.subject_id
                    ORDER BY started_at DESC""")


def save_alarm(label: str, time_value: str, days: str, ringtone: str, subject_id: int | None = None,
               alarm_id: int | None = None, enabled: bool = True) -> int:
    if alarm_id:
        _write("UPDATE alarms SET label=?,time=?,days=?,ringtone=?,subject_id=?,enabled=? WHERE id=?",
               (label, time_value, days, ringtone, subject_id, int(enabled), alarm_id))
        return alarm_id
    return _write("INSERT INTO alarms(label,time,days,ringtone,subject_id,enabled,created_at) VALUES(?,?,?,?,?,?,?)",
                  (label, time_value, days, ringtone, subject_id, int(enabled), datetime.now().isoformat(timespec="seconds")))


def list_alarms(enabled_only: bool = False) -> list[dict]:
    where = "WHERE enabled=1" if enabled_only else ""
    return _rows(f"""SELECT alarms.*, subjects.name AS subject_name
                      FROM alarms LEFT JOIN subjects ON subjects.id=alarms.subject_id
                      {where} ORDER BY time ASC, id DESC""")


def set_alarm_enabled(alarm_id: int, enabled: bool) -> None:
    _write("UPDATE alarms SET enabled=? WHERE id=?", (int(enabled), alarm_id))


def delete_alarm(alarm_id: int) -> None:
    _write("DELETE FROM alarms WHERE id=?", (alarm_id,))


def add_ringtone(name: str, path: str) -> int:
    return _write("INSERT INTO ringtones(name,path) VALUES(?,?)", (name, path))


def list_ringtones() -> list[dict]:
    return _rows("SELECT * FROM ringtones ORDER BY name COLLATE NOCASE")


def get_setting(key: str, default: str = "") -> str:
    result = _one("SELECT value FROM settings WHERE key=?", (key,))
    return str(result["value"]) if result else default


def set_setting(key: str, value: str) -> None:
    _write("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))


def get_goals() -> dict:
    result = _one("SELECT * FROM goals WHERE active=1 ORDER BY id DESC LIMIT 1")
    return result or {"target_minutes_daily": 120, "target_minutes_weekly": 840, "active": 1}


def set_goals(daily: int, weekly: int) -> None:
    with _LOCK, _connection() as connection:
        connection.execute("UPDATE goals SET active=0")
        connection.execute("INSERT INTO goals(target_minutes_daily,target_minutes_weekly,active) VALUES(?,?,1)", (daily, weekly))


def daily_minutes(date_value: str) -> int:
    row = _one("SELECT COALESCE(SUM(minutes),0) AS total FROM sessions WHERE substr(started_at,1,10)=?", (date_value,))
    return int(row["total"] if row else 0)


def minutes_between(start_date: str, end_date: str) -> int:
    row = _one("SELECT COALESCE(SUM(minutes),0) AS total FROM sessions WHERE substr(started_at,1,10)>=? AND substr(started_at,1,10)<=?",
               (start_date, end_date))
    return int(row["total"] if row else 0)


def minutes_per_subject(start_date: str | None = None, end_date: str | None = None) -> list[dict]:
    sql = """SELECT subjects.id, subjects.name, subjects.color,
                     COALESCE(SUM(sessions.minutes),0) AS minutes,
                     COUNT(sessions.id) AS sessions
              FROM subjects LEFT JOIN sessions ON sessions.subject_id=subjects.id"""
    conditions, params = [], []
    if start_date:
        conditions.append("substr(sessions.started_at,1,10)>=?")
        params.append(start_date)
    if end_date:
        conditions.append("substr(sessions.started_at,1,10)<=?")
        params.append(end_date)
    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    sql += " GROUP BY subjects.id ORDER BY minutes DESC, subjects.name"
    return _rows(sql, tuple(params))


def minutes_per_day(days: int = 7) -> list[dict]:
    return _rows("""SELECT substr(started_at,1,10) AS day, SUM(minutes) AS minutes
                  FROM sessions WHERE substr(started_at,1,10)>=date('now', ?)
                  GROUP BY day ORDER BY day""", (f"-{max(0, days - 1)} days",))


def active_streak(today: str) -> int:
    studied = {row["day"] for row in _rows("SELECT DISTINCT substr(started_at,1,10) AS day FROM sessions")}
    from datetime import date, timedelta
    cursor = date.fromisoformat(today)
    if cursor.isoformat() not in studied:
        cursor -= timedelta(days=1)
    streak = 0
    while cursor.isoformat() in studied:
        streak += 1
        cursor -= timedelta(days=1)
    return streak


def export_bytes() -> bytes:
    """Create a consistent SQLite backup and return its bytes."""
    with _LOCK:
        source = _connect()
        try:
            with tempfile.TemporaryDirectory() as folder:
                target_path = os.path.join(folder, "backup.sqlite3")
                target = sqlite3.connect(target_path)
                try:
                    source.backup(target)
                finally:
                    target.close()
                with open(target_path, "rb") as backup_file:
                    return backup_file.read()
        finally:
            if _DB_PATH != ":memory:":
                source.close()


def import_database(source_path: str) -> None:
    """Replace app data from an SQLite backup after validating its schema."""
    incoming = sqlite3.connect(source_path)
    try:
        tables = {row[0] for row in incoming.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {"subjects", "tasks", "sessions", "alarms"}.issubset(tables):
            raise ValueError("ملف قاعدة البيانات غير متوافق")
        if _DB_PATH == ":memory:":
            raise ValueError("استيراد قاعدة البيانات غير متاح في معاينة المتصفح")
        incoming.close()
        if _DB_PATH == ":memory:":
            raise ValueError("استيراد قاعدة البيانات غير متاح في معاينة المتصفح")
        if os.path.abspath(source_path) == os.path.abspath(_DB_PATH):
            return
        with _LOCK:
            descriptor, temporary_path = tempfile.mkstemp(prefix="study-import-", suffix=".sqlite3", dir=os.path.dirname(_DB_PATH))
            os.close(descriptor)
            try:
                shutil.copy2(source_path, temporary_path)
                os.replace(temporary_path, _DB_PATH)
            finally:
                if os.path.exists(temporary_path):
                    os.remove(temporary_path)
    except Exception:
        incoming.close()
        raise
