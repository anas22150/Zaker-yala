"""Cross-screen alarm scheduler; uses a worker thread in installed apps."""
from __future__ import annotations

import asyncio
import logging
import math
import os
import struct
import sys
import threading
import time
import wave
from datetime import datetime
from io import BytesIO
from typing import Awaitable, Callable

from flet_audio import Audio, ReleaseMode

log = logging.getLogger("app.alarm_manager")
AlarmHandler = Callable[[dict], Awaitable[None]]


def default_tone(frequency: int = 660) -> bytes:
    """Create a short chime in memory; no bundled sound file is needed."""
    rate = 22050
    buffer = BytesIO()
    with wave.open(buffer, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(rate)
        samples = bytearray()
        for index in range(rate * 2):
            t = index / rate
            envelope = min(1.0, t * 8, (2 - t) * 5)
            tone = math.sin(2 * math.pi * frequency * t) + 0.38 * math.sin(2 * math.pi * frequency * 1.5 * t)
            samples.extend(struct.pack("<h", int(10000 * envelope * tone / 1.38)))
        wav.writeframes(bytes(samples))
    return buffer.getvalue()


class AlarmManager:
    def __init__(self, audio: Audio, on_alarm: AlarmHandler, *, is_web: bool = False):
        self.audio = audio
        self.on_alarm = on_alarm
        self.is_web = is_web or sys.platform == "emscripten"
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._alarms_provider: Callable[[], list[dict]] = lambda: []
        self._fired: set[tuple[int, str]] = set()
        self.active_alarm_id: int | None = None
        self._calm_tone = default_tone()
        self._sharp_tone = default_tone(880)

    async def start(self, alarms_provider: Callable[[], list[dict]]) -> None:
        self._alarms_provider = alarms_provider
        self._loop = asyncio.get_running_loop()
        if self.is_web:
            asyncio.create_task(self._async_watch())
        else:
            self._thread = threading.Thread(target=self._thread_watch, name="study-alarm-scheduler", daemon=True)
            self._thread.start()
        log.info("alarm scheduler started (web=%s)", self.is_web)

    def _due_alarms(self) -> list[dict]:
        now = datetime.now()
        day_key = now.date().isoformat()
        if now.hour == 0 and now.minute == 0:
            self._fired.clear()
        due = []
        for alarm in self._alarms_provider():
            marker = (int(alarm["id"]), day_key)
            days = alarm.get("days", "all")
            day_matches = days == "all" or now.weekday() in {
                int(value) for value in days.split(",") if value.strip().isdigit()
            }
            if alarm.get("enabled") and alarm.get("time") == now.strftime("%H:%M") and day_matches and marker not in self._fired:
                self._fired.add(marker)
                due.append(dict(alarm))
        return due

    def _dispatch(self, alarm: dict) -> None:
        if not self._loop or self._loop.is_closed():
            return
        def launch() -> None:
            asyncio.create_task(self.on_alarm(alarm))
        self._loop.call_soon_threadsafe(launch)

    def _thread_watch(self) -> None:
        while not self._stop.is_set():
            try:
                for alarm in self._due_alarms():
                    self._dispatch(alarm)
            except Exception:
                log.exception("alarm scheduler iteration failed")
            self._stop.wait(1.0)

    async def _async_watch(self) -> None:
        while True:
            try:
                for alarm in self._due_alarms():
                    await self.on_alarm(alarm)
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("alarm scheduler iteration failed")
            await asyncio.sleep(1)

    async def ring(self, alarm: dict) -> bool:
        self.active_alarm_id = int(alarm["id"])
        ringtone = alarm.get("ringtone") or ""
        try:
            try:
                await self.audio.pause()
            except Exception:
                log.debug("audio player was not active before alarm")
            try:
                await self.audio.release()
            except Exception:
                log.debug("audio player had no resources to release before alarm")
            if ringtone and os.path.isfile(ringtone):
                self.audio.src = ringtone
            else:
                self.audio.src = self._sharp_tone if ringtone == "نغمة حادة" else self._calm_tone
            self.audio.release_mode = ReleaseMode.LOOP
            self.audio.volume = 1.0
            await self.audio.play()
            log.info("alarm audio started for alarm %s", self.active_alarm_id)
            return True
        except Exception:
            log.exception("could not start alarm audio")
            return False

    async def preview_sound(self, ringtone_path: str | None = None) -> bool:
        """Play one short sound to verify the device's audio output and imported file."""
        if self.active_alarm_id is not None:
            return False
        try:
            try:
                await self.audio.pause()
            except Exception:
                log.debug("audio player was not active before preview")
            try:
                await self.audio.release()
            except Exception:
                log.debug("audio player had no resources to release before preview")
            self.audio.src = ringtone_path if ringtone_path and os.path.isfile(ringtone_path) else self._calm_tone
            self.audio.release_mode = ReleaseMode.RELEASE
            self.audio.volume = 1.0
            await self.audio.play()
            log.info("audio preview started")
            return True
        except Exception:
            log.exception("could not play audio preview")
            return False

    async def stop_ringing(self) -> None:
        self.active_alarm_id = None
        try:
            await self.audio.pause()
            await self.audio.release()
        except Exception:
            log.exception("could not stop alarm audio")

    def shutdown(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1)
