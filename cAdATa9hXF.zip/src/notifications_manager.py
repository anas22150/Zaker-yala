"""Android local-notification scheduling for alarms that must outlive the app process."""
from __future__ import annotations

import inspect
import json
import logging
from datetime import date, datetime, time, timedelta
from typing import Any

from flet_notifications import Notifications

log = logging.getLogger("app.notifications")


class LocalNotificationScheduler:
    """Schedule a rolling window of native OS notifications for enabled alarms."""

    HORIZON_DAYS = 30
    MAX_SCHEDULES = 300

    def __init__(self, page):
        self.page = page
        # Initialize the native plugin only when an Android capability is used.
        # This keeps Windows and the Studio web preview from touching Android APIs.
        self.service = None

    def _service(self):
        if self.service is None:
            self.service = Notifications()
        return self.service

    @staticmethod
    async def _await_if_needed(result):
        if inspect.isawaitable(result):
            return await result
        return result

    async def request_permission(self):
        service = self._service()
        return await self._await_if_needed(service.request_permissions())

    @staticmethod
    def _invoke(method, values: dict[str, Any]):
        """Pass only parameters supported by the installed extension version."""
        signature = inspect.signature(method)
        aliases = {
            "id": "notification_id",
            "notification_id": "notification_id",
            "title": "title",
            "body": "body",
            "payload": "payload",
            "data": "payload",
            "scheduled_date_time": "scheduled_date_time",
            "schedule_date_time": "scheduled_date_time",
            "scheduled_datetime": "scheduled_date_time",
            "scheduled_date": "scheduled_date_time",
            "scheduled_time": "scheduled_date_time",
            "schedule_time": "scheduled_date_time",
            "schedule_at": "scheduled_date_time",
            "date_time": "scheduled_date_time",
            "datetime": "scheduled_date_time",
            "date": "scheduled_date_time",
            "when": "scheduled_date_time",
            "at": "scheduled_date_time",
            "time": "scheduled_date_time",
        }
        kwargs = {}
        has_kwargs = False
        for name, parameter in signature.parameters.items():
            if parameter.kind == inspect.Parameter.VAR_KEYWORD:
                has_kwargs = True
                continue
            source = aliases.get(name)
            if source and source in values:
                kwargs[name] = values[source]
            elif parameter.default is inspect.Parameter.empty and parameter.kind not in (
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
            ):
                raise RuntimeError(f"الإشعارات تتطلب وسيطاً غير مدعوم: {name}")
        if has_kwargs:
            for key in ("notification_id", "title", "body", "scheduled_date_time", "payload"):
                kwargs.setdefault(key, values[key])
        return method(**kwargs)

    async def _cancel(self, notification_id: int):
        service = self._service()
        cancel_method = next((getattr(service, name, None) for name in ("cancel", "cancel_notification")
                              if callable(getattr(service, name, None))), None)
        if not cancel_method:
            log.warning("The notification extension has no cancel method; stale OS notifications may remain")
            return
        values = {"notification_id": notification_id, "title": "", "body": "",
                  "scheduled_date_time": datetime.now(), "payload": ""}
        await self._await_if_needed(self._invoke(cancel_method, values))

    async def sync(self, alarms: list[dict], previous_ids: str = "[]") -> list[int]:
        if self.page.web:
            raise RuntimeError("الإشعارات المجدولة تعمل في تطبيق Android المثبت فقط")
        if "android" not in str(self.page.platform).lower():
            raise RuntimeError("الإشعارات المجدولة في الخلفية مهيأة لنسخة Android")

        try:
            old_ids = [int(value) for value in json.loads(previous_ids)]
        except (ValueError, TypeError, json.JSONDecodeError):
            old_ids = []
        service = self._service()
        schedule_method = getattr(service, "schedule", None)
        if not callable(schedule_method):
            raise RuntimeError("إصدار حزمة الإشعارات لا يدعم جدولة الإشعار")

        now = datetime.now()
        scheduled_ids: list[int] = []
        for alarm in alarms:
            try:
                hour, minute = (int(part) for part in alarm["time"].split(":"))
            except (KeyError, TypeError, ValueError):
                log.warning("Skipping alarm with invalid time: %s", alarm)
                continue
            days = alarm.get("days", "all")
            allowed_days = None if days == "all" else {
                int(value) for value in days.split(",") if value.strip().isdigit()
            }
            subject = alarm.get("subject_name")
            for offset in range(self.HORIZON_DAYS):
                scheduled_day = date.today() + timedelta(days=offset)
                scheduled_at = datetime.combine(scheduled_day, time(hour=hour, minute=minute))
                if scheduled_at <= now or (allowed_days is not None and scheduled_day.weekday() not in allowed_days):
                    continue
                # Stable IDs let a future sync replace/cancel this alarm's pending occurrences.
                notification_id = int(alarm["id"]) * 100 + offset + 1
                values = {
                    "notification_id": notification_id,
                    "title": alarm.get("label", "موعد المذاكرة"),
                    "body": "حان وقت المذاكرة" + (f" · {subject}" if subject else "") + " — اضغطي لفتح التطبيق.",
                    "scheduled_date_time": scheduled_at,
                    "payload": str(alarm["id"]),
                }
                await self._await_if_needed(self._invoke(schedule_method, values))
                scheduled_ids.append(notification_id)
                if len(scheduled_ids) >= self.MAX_SCHEDULES:
                    log.warning("Notification schedule reached its %s item safety limit", self.MAX_SCHEDULES)
                    break
            if len(scheduled_ids) >= self.MAX_SCHEDULES:
                break
        new_id_set = set(scheduled_ids)
        for notification_id in old_ids:
            if notification_id not in new_id_set:
                await self._cancel(notification_id)
        return scheduled_ids
