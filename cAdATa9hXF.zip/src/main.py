from __future__ import annotations

import asyncio
import json
import logging
import os
import tempfile
from datetime import date, datetime

import flet as ft
import flet_charts as fc
from flet_audio import Audio

import database as db
from alarm_manager import AlarmManager
from notifications_manager import LocalNotificationScheduler
from utils import format_minutes, month_bounds, today_iso, week_bounds

LOG_LEVEL = logging.INFO
logging.basicConfig(format="%(levelname)s %(name)s: %(message)s")
logging.getLogger("app").setLevel(LOG_LEVEL)
log = logging.getLogger("app.main")

COLOR_OPTIONS = {
    "أزرق": ft.Colors.BLUE,
    "بنفسجي": ft.Colors.PURPLE,
    "أخضر": ft.Colors.GREEN,
    "برتقالي": ft.Colors.ORANGE,
    "أحمر": ft.Colors.RED,
    "فيروزي": ft.Colors.TEAL,
}


def subject_color(value: str | None):
    return COLOR_OPTIONS.get(value or "أزرق", ft.Colors.BLUE)


def subject_label(subject: dict) -> str:
    return f"{subject['name']}  ·  #{subject['id']}"


def option_for(label: str) -> ft.DropdownOption:
    return ft.DropdownOption(text=label)


class StudyApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.page.title = "يلا قوم ذاكر"
        self.page.rtl = True
        self.page.padding = 16
        self.page.spacing = 12
        self.page.bgcolor = ft.Colors.BLUE_GREY_50
        font_name = "Tahoma" if "windows" in str(page.platform).lower() else "NotoNaskhArabic"
        self.page.theme = ft.Theme(color_scheme_seed=ft.Colors.INDIGO, use_material3=True, font_family=font_name)
        self.page.theme_mode = ft.ThemeMode.LIGHT
        db.init_db()

        self.audio = Audio()
        self.file_picker = ft.FilePicker()
        self.alarm_manager = AlarmManager(self.audio, self.show_alarm, is_web=page.web)
        self.notification_scheduler = LocalNotificationScheduler(page)
        self.active_alarm: dict | None = None
        self.current_screen = "home"
        self.selected_alarm_subject: int | None = None
        self.pomodoro_minutes = 25
        self.remaining_seconds = self.pomodoro_minutes * 60
        self.timer_running = False
        self.timer_task: asyncio.Task | None = None
        self.timer_label = ft.Text("25:00", size=42, weight=ft.FontWeight.BOLD, color=ft.Colors.INDIGO)
        self.timer_ring = ft.ProgressRing(value=0, stroke_width=8, color=ft.Colors.INDIGO, bgcolor=ft.Colors.INDIGO_50)
        self.pomodoro_subject: int | None = None
        self._timer_started_at: datetime | None = None
        self._rendered = False

    async def start(self):
        await self.alarm_manager.start(lambda: db.list_alarms(enabled_only=True))
        if db.get_setting("background_notifications_enabled", "0") == "1":
            await self.sync_notifications(show_feedback=False)
        self.render("home")

    async def _request_and_schedule_android_notifications(self) -> bool:
        if self.page.web or "android" not in str(self.page.platform).lower():
            return False
        try:
            result = await self.notification_scheduler.request_permission()
            status = str(result).lower()
            if result is False or "denied" in status or "permanentlydenied" in status:
                return False
            db.set_setting("background_notifications_enabled", "1")
            return bool(await self.sync_notifications(show_feedback=False))
        except Exception:
            log.exception("notification permission or scheduling failed")
            return False

    async def enable_background_notifications(self):
        if self.page.web or "android" not in str(self.page.platform).lower():
            self.notify("الإشعارات المجدولة متاحة في نسخة Android المثبتة.", ft.Colors.ORANGE)
            return
        if await self._request_and_schedule_android_notifications():
            self.notify("تم تفعيل الإذن وجدولة المنبهات للأيام القادمة.", ft.Colors.GREEN)
        else:
            self.notify("لم يكتمل الإذن أو الجدولة. افتحي إعدادات Android الموضحة هنا واسمحي بالإشعارات والتنبيهات الدقيقة.", ft.Colors.ORANGE)

    async def test_alarm_sound(self):
        if await self.alarm_manager.preview_sound():
            self.notify("بدأ اختبار الصوت. تأكدي من رفع صوت الوسائط في الهاتف.", ft.Colors.GREEN)
        else:
            self.notify("تعذر تشغيل الصوت. افحصي صوت الوسائط وجربي ملف WAV أو MP3.", ft.Colors.RED)

    async def sync_notifications(self, *, show_feedback: bool = True):
        if db.get_setting("background_notifications_enabled", "0") != "1":
            return
        try:
            ids = await self.notification_scheduler.sync(
                db.list_alarms(enabled_only=True),
                db.get_setting("scheduled_notification_ids", "[]"),
            )
            db.set_setting("scheduled_notification_ids", json.dumps(ids))
            log.info("scheduled %d Android alarm notifications", len(ids))
            return True
        except Exception as exc:
            log.exception("background notification scheduling failed")
            if show_feedback:
                self.notify(f"تعذرت جدولة إشعارات المنبهات: {exc}", ft.Colors.RED)
            return False

    def notify(self, message: str, color=ft.Colors.INDIGO):
        self.page.show_dialog(ft.SnackBar(content=ft.Text(message), bgcolor=color, duration=3000))

    def card(self, content: ft.Control, *, padding=16, color=ft.Colors.WHITE):
        return ft.Container(
            content=content,
            padding=padding,
            bgcolor=color,
            border_radius=20,
            border=ft.Border.all(1, ft.Colors.BLUE_GREY_100),
        )

    def header(self, title: str, subtitle: str | None = None):
        controls = [ft.Text(title, size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_GREY_900)]
        if subtitle:
            controls.append(ft.Text(subtitle, size=13, color=ft.Colors.BLUE_GREY_600))
        return ft.Column(tight=True, spacing=4, controls=controls)

    def text_field(self, label: str, *, value: str = "", hint: str | None = None, number=False, read_only=False):
        return ft.TextField(
            label=label,
            value=value,
            hint_text=hint,
            keyboard_type=ft.KeyboardType.NUMBER if number else ft.KeyboardType.TEXT,
            text_align=ft.TextAlign.RIGHT,
            read_only=read_only,
            border_radius=14,
        )

    def primary_button(self, label: str, icon, callback, *, color=ft.Colors.INDIGO):
        return ft.Button(
            content=label,
            icon=icon,
            bgcolor=color,
            color=ft.Colors.WHITE,
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=14)),
            on_click=callback,
        )

    def render(self, screen: str):
        self.current_screen = screen
        labels = {
            "home": "يلا قوم ذاكر",
            "subjects": "المواد الدراسية",
            "tasks": "المهام",
            "pomodoro": "جلسة المذاكرة",
            "statistics": "إحصائياتك",
            "alarms": "منبهات المذاكرة",
            "settings": "الإعدادات",
        }
        title = labels.get(screen, "يلا قوم ذاكر")
        leading = None if screen == "home" else ft.IconButton(icon=ft.Icons.ARROW_BACK, tooltip="الرئيسية", on_click=lambda: self.render("home"))
        self.page.appbar = ft.AppBar(
            leading=leading,
            title=ft.Text(title, weight=ft.FontWeight.BOLD),
            center_title=False,
            bgcolor=ft.Colors.BLUE_GREY_50,
            color=ft.Colors.BLUE_GREY_900,
            actions=[ft.IconButton(icon=ft.Icons.SETTINGS, tooltip="الإعدادات", on_click=lambda: self.render("settings"))] if screen != "settings" else [],
        )
        self.page.clean()
        builders = {
            "home": self.home_view,
            "subjects": self.subjects_view,
            "tasks": self.tasks_view,
            "pomodoro": self.pomodoro_view,
            "statistics": self.statistics_view,
            "alarms": self.alarms_view,
            "settings": self.settings_view,
        }
        body = builders.get(screen, self.home_view)()
        self.page.add(ft.SafeArea(content=body, expand=True))
        self.page.update()
        self._rendered = True

    def home_view(self):
        today = today_iso()
        goals = db.get_goals()
        studied = db.daily_minutes(today)
        target = max(1, int(goals["target_minutes_daily"]))
        ratio = min(1.0, studied / target)
        week_start, week_end = week_bounds()
        month_start, month_end = month_bounds()
        subjects = db.list_subjects()
        tasks = [task for task in db.list_tasks() if not task["done"] and task["due_date"] <= today]
        alarms = db.list_alarms(enabled_only=True)[:3]
        stats = [
            ("الاستمرارية", f"{db.active_streak(today)} يوم", ft.Icons.LOCAL_FIRE_DEPARTMENT, ft.Colors.ORANGE),
            ("هذا الأسبوع", format_minutes(db.minutes_between(week_start, week_end)), ft.Icons.TRENDING_UP, ft.Colors.GREEN),
            ("هذا الشهر", format_minutes(db.minutes_between(month_start, month_end)), ft.Icons.CALENDAR_MONTH, ft.Colors.PURPLE),
            ("المواد", str(len(subjects)), ft.Icons.MENU_BOOK, ft.Colors.BLUE),
        ]
        stat_cards = [self.card(ft.Column(tight=True, spacing=8, controls=[
            ft.Icon(icon, color=color, size=23),
            ft.Text(value, size=17, weight=ft.FontWeight.BOLD),
            ft.Text(label, size=12, color=ft.Colors.BLUE_GREY_600),
        ]), padding=14) for label, value, icon, color in stats]
        menu = [
            ("المذاكرة", ft.Icons.TIMER, "pomodoro", ft.Colors.INDIGO),
            ("المواد", ft.Icons.MENU_BOOK, "subjects", ft.Colors.BLUE),
            ("المهام", ft.Icons.TASK_ALT, "tasks", ft.Colors.GREEN),
            ("الإحصائيات", ft.Icons.ANALYTICS, "statistics", ft.Colors.PURPLE),
            ("المنبهات", ft.Icons.ALARM, "alarms", ft.Colors.ORANGE),
            ("الإعدادات", ft.Icons.SETTINGS, "settings", ft.Colors.BLUE_GREY),
        ]
        tiles = []
        for label, icon, route, tint in menu:
            tiles.append(ft.Container(
                content=ft.Column(tight=True, spacing=9, horizontal_alignment=ft.CrossAxisAlignment.CENTER, controls=[
                    ft.Icon(icon, size=30, color=tint), ft.Text(label, weight=ft.FontWeight.W_600),
                ]),
                padding=14,
                alignment=ft.Alignment.CENTER,
                bgcolor=ft.Colors.WHITE,
                border_radius=18,
                border=ft.Border.all(1, ft.Colors.BLUE_GREY_100),
                on_click=lambda e, destination=route: self.render(destination),
            ))
        task_controls = [
            ft.ListTile(
                title=ft.Text(task["title"], max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
                subtitle=ft.Text(f"استحقاق: {task['due_date']}"),
                leading=ft.Icon(ft.Icons.CHECK_CIRCLE_OUTLINE, color=ft.Colors.INDIGO),
                on_click=lambda e, destination="tasks": self.render(destination),
            ) for task in tasks[:4]
        ] or [ft.Text("لا توجد مهام مستحقة اليوم. بداية ممتازة!", color=ft.Colors.BLUE_GREY_600)]
        alarm_controls = [
            ft.ListTile(
                title=ft.Text(alarm["label"]),
                subtitle=ft.Text(alarm.get("subject_name") or "منبه مذاكرة"),
                leading=ft.Text(alarm["time"], size=16, weight=ft.FontWeight.BOLD, color=ft.Colors.INDIGO),
            ) for alarm in alarms
        ] or [ft.Text("أضف منبهاً ليذكّرك بموعد المذاكرة.", color=ft.Colors.BLUE_GREY_600)]
        content = ft.Column(expand=True, scroll=ft.ScrollMode.AUTO, spacing=16, controls=[
            self.card(ft.Column(spacing=10, controls=[
                ft.Row(vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[
                    ft.Image(src="icon.png", width=56, height=56, fit=ft.BoxFit.CONTAIN),
                    ft.Column(expand=True, tight=True, spacing=3, controls=[
                        ft.Text("جاهز تحقق هدفك؟", size=20, weight=ft.FontWeight.BOLD),
                        ft.Text("خطوة صغيرة اليوم تصنع فرقاً كبيراً.", color=ft.Colors.BLUE_GREY_600),
                    ]),
                ]),
                ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN, controls=[
                    ft.Text(f"{format_minutes(studied)} من {format_minutes(target)}", weight=ft.FontWeight.W_600),
                    ft.Text(f"{int(ratio * 100)}٪", color=ft.Colors.INDIGO, weight=ft.FontWeight.BOLD),
                ]),
                ft.ProgressBar(value=ratio, color=ft.Colors.INDIGO, bgcolor=ft.Colors.INDIGO_50, bar_height=9, border_radius=8),
            ])),
            ft.GridView(expand=False, max_extent=160, child_aspect_ratio=1.45, spacing=10, run_spacing=10, controls=stat_cards),
            self.header("ابدأ من هنا", "كل أدوات مذاكرتك في مكان واحد"),
            ft.GridView(expand=False, max_extent=145, child_aspect_ratio=1.32, spacing=10, run_spacing=10, controls=tiles),
            self.card(ft.Column(tight=True, spacing=4, controls=[
                ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN, controls=[self.header("مهام اليوم"), ft.TextButton("عرض الكل", on_click=lambda: self.render("tasks"))]),
                *task_controls,
            ])),
            self.card(ft.Column(tight=True, spacing=4, controls=[
                ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN, controls=[self.header("منبهاتك القادمة"), ft.TextButton("إدارة", on_click=lambda: self.render("alarms"))]),
                *alarm_controls,
            ])),
        ])
        return content

    def subjects_view(self):
        subjects = db.list_subjects()
        cards = []
        for subject in subjects:
            tint = subject_color(subject["color"])
            cards.append(self.card(ft.Row(vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[
                ft.Container(width=6, height=64, bgcolor=tint, border_radius=6),
                ft.Column(expand=True, spacing=4, controls=[
                    ft.Text(subject["name"], size=18, weight=ft.FontWeight.BOLD),
                    ft.Text(f"إجمالي المذاكرة: {format_minutes(subject['total_minutes'])}", color=ft.Colors.BLUE_GREY_600),
                    ft.Text(f"هدف أسبوعي: {subject['weekly_goal']} ساعة", size=12, color=ft.Colors.BLUE_GREY_500),
                ]),
                ft.IconButton(icon=ft.Icons.EDIT, tooltip="تعديل", on_click=lambda e, row=subject: self.subject_dialog(row)),
                ft.IconButton(icon=ft.Icons.DELETE_OUTLINE, tooltip="حذف", icon_color=ft.Colors.RED, on_click=lambda e, sid=subject["id"]: self.confirm_delete_subject(sid)),
            ]), padding=14))
        if not cards:
            cards = [self.card(ft.Column(tight=True, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10, controls=[
                ft.Icon(ft.Icons.MENU_BOOK, size=42, color=ft.Colors.INDIGO_300),
                ft.Text("لم تضف أي مادة بعد", size=18, weight=ft.FontWeight.BOLD),
                ft.Text("أضف موادك لتسجيل جلسات المذاكرة ومتابعة تقدمك.", text_align=ft.TextAlign.CENTER, color=ft.Colors.BLUE_GREY_600),
            ]))]
        return ft.Column(expand=True, spacing=14, controls=[
            ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN, controls=[self.header("موادي", "أضف المواد التي تدرسها وتابع وقتك فيها"), self.primary_button("إضافة مادة", ft.Icons.ADD, lambda: self.subject_dialog())]),
            ft.Column(expand=True, scroll=ft.ScrollMode.AUTO, spacing=10, controls=cards),
        ])

    def subject_dialog(self, subject: dict | None = None):
        name = self.text_field("اسم المادة", value=subject["name"] if subject else "")
        color = ft.Dropdown(label="لون المادة", value=subject.get("color", "أزرق") if subject else "أزرق", options=[option_for(label) for label in COLOR_OPTIONS])
        weekly = self.text_field("الهدف الأسبوعي بالساعات", value=str(subject["weekly_goal"] if subject else 3), number=True)
        def save():
            title = (name.value or "").strip()
            try:
                goal = int(weekly.value or "0")
            except ValueError:
                self.notify("أدخل هدفاً أسبوعياً صحيحاً.", ft.Colors.RED)
                return
            if not title or goal < 0:
                self.notify("اكتب اسم المادة وهدفاً صحيحاً.", ft.Colors.RED)
                return
            db.save_subject(title, color.value or "أزرق", goal, subject.get("id") if subject else None)
            self.page.pop_dialog()
            self.render("subjects")
            self.notify("تم حفظ المادة بنجاح.", ft.Colors.GREEN)
        self.page.show_dialog(ft.AlertDialog(
            modal=True,
            title=ft.Text("تعديل المادة" if subject else "إضافة مادة"),
            content=ft.Column(tight=True, spacing=12, controls=[name, color, weekly]),
            actions=[ft.TextButton("إلغاء", on_click=lambda: self.page.pop_dialog()), self.primary_button("حفظ", ft.Icons.CHECK, save)],
            actions_alignment=ft.MainAxisAlignment.END,
        ))

    def confirm_delete_subject(self, subject_id: int):
        def remove():
            db.delete_subject(subject_id)
            self.page.pop_dialog()
            self.render("subjects")
            self.notify("تم حذف المادة.")
        self.page.show_dialog(ft.AlertDialog(
            modal=True, title=ft.Text("حذف المادة؟"), content=ft.Text("ستبقى الجلسات والمهام السابقة محفوظة دون ربط بالمادة."),
            actions=[ft.TextButton("إلغاء", on_click=lambda: self.page.pop_dialog()), ft.TextButton("حذف", on_click=remove)],
        ))

    def tasks_view(self):
        tasks = db.list_tasks()
        active = [task for task in tasks if not task["done"]]
        completed = [task for task in tasks if task["done"]]
        def task_tile(task: dict):
            title = ft.Text(("✓  " if task["done"] else "") + task["title"], max_lines=2,
                            overflow=ft.TextOverflow.ELLIPSIS,
                            color=ft.Colors.BLUE_GREY_500 if task["done"] else ft.Colors.ON_SURFACE)
            return self.card(ft.Row(vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[
                ft.Checkbox(value=bool(task["done"]), on_change=lambda e, tid=task["id"]: self.toggle_task(tid, e.control.value)),
                ft.Column(expand=True, spacing=3, controls=[title, ft.Text(
                    f"{task['due_date']}" + (f" · {task['subject_name']}" if task.get("subject_name") else ""),
                    size=12, color=ft.Colors.BLUE_GREY_600,
                )]),
                ft.IconButton(icon=ft.Icons.DELETE_OUTLINE, tooltip="حذف المهمة", on_click=lambda e, tid=task["id"]: self.delete_task(tid)),
            ]), padding=8)
        controls = [ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN, controls=[
            self.header("مهامي", "خطط ليومك وأنجز مهمة تلو الأخرى"), self.primary_button("مهمة جديدة", ft.Icons.ADD, lambda: self.task_dialog()),
        ])]
        if active:
            controls.extend([self.header("قيد الإنجاز"), *(task_tile(task) for task in active)])
        else:
            controls.append(self.card(ft.Text("لا توجد مهام نشطة. أضف مهمة جديدة وابدأ!", color=ft.Colors.BLUE_GREY_600)))
        if completed:
            controls.extend([ft.Divider(), self.header("مكتملة"), *(task_tile(task) for task in completed)])
        return ft.Column(expand=True, scroll=ft.ScrollMode.AUTO, spacing=12, controls=controls)

    def toggle_task(self, task_id: int, checked: bool):
        db.set_task_done(task_id, checked)
        self.render("tasks")
        self.notify("أحسنت! تم إنجاز المهمة." if checked else "أعيدت المهمة إلى القائمة.", ft.Colors.GREEN if checked else ft.Colors.INDIGO)

    def delete_task(self, task_id: int):
        db.delete_task(task_id)
        self.render("tasks")
        self.notify("تم حذف المهمة.")

    def task_dialog(self):
        title = self.text_field("عنوان المهمة")
        due = self.text_field("تاريخ الاستحقاق", value=today_iso(), read_only=True)
        picker = ft.DatePicker(
            value=datetime.now(), first_date=datetime(2020, 1, 1), last_date=datetime(2100, 12, 31),
            help_text="اختر تاريخ الاستحقاق", cancel_text="إلغاء", confirm_text="اختيار",
            on_change=lambda e: self.set_due_date(due, e.control.value),
        )
        def open_date():
            self.page.show_dialog(picker)
        subjects = db.list_subjects()
        subject_items = [{"id": None, "label": "بدون مادة"}] + [{"id": s["id"], "label": subject_label(s)} for s in subjects]
        subject = ft.Dropdown(label="المادة (اختياري)", value="بدون مادة", options=[option_for(item["label"]) for item in subject_items])
        def save():
            if not (title.value or "").strip():
                self.notify("اكتب عنوان المهمة أولاً.", ft.Colors.RED)
                return
            selected = next((item["id"] for item in subject_items if item["label"] == subject.value), None)
            db.save_task(title.value.strip(), due.value or today_iso(), selected)
            self.page.pop_dialog()
            self.render("tasks")
            self.notify("تمت إضافة المهمة.", ft.Colors.GREEN)
        self.page.show_dialog(ft.AlertDialog(
            modal=True, title=ft.Text("مهمة جديدة"),
            content=ft.Column(tight=True, spacing=10, controls=[title, ft.Row(controls=[due, ft.IconButton(icon=ft.Icons.CALENDAR_MONTH, on_click=lambda: open_date())]), subject]),
            actions=[ft.TextButton("إلغاء", on_click=lambda: self.page.pop_dialog()), self.primary_button("إضافة", ft.Icons.ADD, save)],
        ))

    @staticmethod
    def set_due_date(field: ft.TextField, value):
        if value:
            field.value = value.astimezone().date().isoformat()
            field.update()

    def pomodoro_view(self):
        subjects = db.list_subjects()
        subject_items = [{"id": None, "label": "بدون مادة"}] + [{"id": s["id"], "label": subject_label(s)} for s in subjects]
        selected_value = next((item["label"] for item in subject_items if item["id"] == self.pomodoro_subject), "بدون مادة")
        subject_dropdown = ft.Dropdown(label="المادة", value=selected_value, options=[option_for(item["label"]) for item in subject_items])
        duration = ft.Dropdown(
            label="مدة الجلسة", value=f"{self.pomodoro_minutes} دقيقة",
            options=[option_for(f"{value} دقيقة") for value in (15, 25, 50, 90)] + [option_for("مخصص")],
            on_select=lambda e: self.select_duration(e.control.value),
        )
        self.subject_dropdown = subject_dropdown
        self.duration_dropdown = duration
        self.timer_label.value = self.format_clock(self.remaining_seconds)
        progress = 1 - self.remaining_seconds / max(1, self.pomodoro_minutes * 60)
        self.timer_ring.value = min(1, max(0, progress))
        return ft.Column(expand=True, scroll=ft.ScrollMode.AUTO, spacing=16, horizontal_alignment=ft.CrossAxisAlignment.CENTER, controls=[
            self.header("جلسة تركيز", "اختر مادة ومدة، ثم ابدأ جلسة هادئة"),
            self.card(ft.Column(horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=20, controls=[
                ft.Row(controls=[subject_dropdown, duration]),
                ft.Container(width=220, height=220, alignment=ft.Alignment.CENTER, content=ft.Stack(alignment=ft.Alignment.CENTER, controls=[
                    ft.ProgressRing(value=self.timer_ring.value, width=200, height=200, stroke_width=10, color=ft.Colors.INDIGO, bgcolor=ft.Colors.INDIGO_50),
                    self.timer_label,
                ])),
                ft.Text("كل دقيقة من تركيزك تقرّبك من هدفك", color=ft.Colors.BLUE_GREY_600),
                ft.Row(wrap=True, alignment=ft.MainAxisAlignment.CENTER, spacing=10, controls=[
                    self.primary_button("ابدأ", ft.Icons.PLAY_ARROW, self.start_timer, color=ft.Colors.GREEN),
                    ft.OutlinedButton(content="إيقاف مؤقت", icon=ft.Icons.PAUSE, on_click=self.pause_timer),
                    ft.OutlinedButton(content="إيقاف", icon=ft.Icons.STOP, on_click=self.stop_timer),
                ]),
            ])),
            self.card(ft.Text("عند انتهاء المؤقت، ستظهر لك نافذة لحفظ الجلسة. لا تُسجّل الجلسة إلا بعد تأكيدك.", text_align=ft.TextAlign.CENTER, color=ft.Colors.BLUE_GREY_600)),
        ])

    @staticmethod
    def format_clock(seconds: int) -> str:
        minutes, secs = divmod(max(0, seconds), 60)
        return f"{minutes:02d}:{secs:02d}"

    def select_duration(self, value: str | None):
        if value == "مخصص":
            minutes = self.text_field("مدة الجلسة بالدقائق", value="30", number=True)
            def apply():
                try:
                    chosen = int(minutes.value or "0")
                    if not 1 <= chosen <= 240:
                        raise ValueError
                except ValueError:
                    self.notify("اختر مدة بين دقيقة و240 دقيقة.", ft.Colors.RED)
                    return
                self.pomodoro_minutes = chosen
                self.remaining_seconds = chosen * 60
                self.page.pop_dialog()
                self.render("pomodoro")
            self.page.show_dialog(ft.AlertDialog(modal=True, title=ft.Text("مدة مخصصة"), content=minutes,
                actions=[ft.TextButton("إلغاء", on_click=lambda: self.page.pop_dialog()), self.primary_button("تأكيد", ft.Icons.CHECK, apply)]))
            return
        if value:
            self.pomodoro_minutes = int(value.split()[0])
            if not self.timer_running:
                self.remaining_seconds = self.pomodoro_minutes * 60
                self.render("pomodoro")

    async def start_timer(self):
        if self.timer_running:
            return
        if self.remaining_seconds <= 0:
            self.remaining_seconds = self.pomodoro_minutes * 60
        selected = getattr(self, "subject_dropdown", None)
        selected_text = selected.value if selected else "بدون مادة"
        self.pomodoro_subject = next((s["id"] for s in db.list_subjects() if subject_label(s) == selected_text), self.pomodoro_subject)
        self.timer_running = True
        self._timer_started_at = datetime.now()
        self.timer_task = asyncio.create_task(self._tick_timer())

    async def _tick_timer(self):
        try:
            while self.timer_running and self.remaining_seconds > 0:
                await asyncio.sleep(1)
                if not self.timer_running:
                    return
                self.remaining_seconds -= 1
                self.timer_label.value = self.format_clock(self.remaining_seconds)
                self.timer_ring.value = 1 - self.remaining_seconds / max(1, self.pomodoro_minutes * 60)
                self.page.update()
            if self.timer_running and self.remaining_seconds <= 0:
                self.timer_running = False
                self.show_session_complete()
        except asyncio.CancelledError:
            return

    def pause_timer(self):
        self.timer_running = False
        if self.timer_task and not self.timer_task.done():
            self.timer_task.cancel()
        self.notify("تم إيقاف المؤقت مؤقتاً.")

    def stop_timer(self):
        self.timer_running = False
        if self.timer_task and not self.timer_task.done():
            self.timer_task.cancel()
        self.remaining_seconds = self.pomodoro_minutes * 60
        self.timer_label.value = self.format_clock(self.remaining_seconds)
        self.timer_ring.value = 0
        self.page.update()
        self.notify("تم إيقاف الجلسة وإعادة ضبط المؤقت.")

    def show_session_complete(self):
        def save_session():
            started = self._timer_started_at.isoformat(timespec="seconds") if self._timer_started_at else datetime.now().isoformat(timespec="seconds")
            db.add_session(self.pomodoro_subject, self.pomodoro_minutes, "study", started)
            self.page.pop_dialog()
            self.render("home")
            self.notify("تم حفظ جلستك. أحسنت!", ft.Colors.GREEN)
        self.page.show_dialog(ft.AlertDialog(
            modal=True, title=ft.Text("أحسنت! 🎉"),
            content=ft.Column(tight=True, horizontal_alignment=ft.CrossAxisAlignment.CENTER, controls=[
                ft.Icon(ft.Icons.STARS, size=54, color=ft.Colors.AMBER),
                ft.Text(f"أكملت {self.pomodoro_minutes} دقيقة من التركيز."),
                ft.Text("هل تريد حفظ هذه الجلسة؟", color=ft.Colors.BLUE_GREY_600),
            ]),
            actions=[ft.TextButton("لاحقاً", on_click=lambda: self.page.pop_dialog()), self.primary_button("حفظ الجلسة", ft.Icons.CHECK, save_session, color=ft.Colors.GREEN)],
            actions_alignment=ft.MainAxisAlignment.CENTER,
        ))

    def statistics_view(self):
        now = date.today()
        week_start, week_end = week_bounds(now)
        month_start, month_end = month_bounds(now)
        daily = db.daily_minutes(today_iso())
        weekly = db.minutes_between(week_start, week_end)
        monthly = db.minutes_between(month_start, month_end)
        subjects = db.minutes_per_subject()
        sessions = db.session_rows()
        streak = db.active_streak(today_iso())
        stats = [
            ("سلسلة الأيام", f"{streak} يوم", ft.Icons.LOCAL_FIRE_DEPARTMENT, ft.Colors.ORANGE),
            ("اليوم", format_minutes(daily), ft.Icons.TODAY, ft.Colors.GREEN),
            ("الأسبوع", format_minutes(weekly), ft.Icons.DATE_RANGE, ft.Colors.BLUE),
            ("الشهر", format_minutes(monthly), ft.Icons.CALENDAR_MONTH, ft.Colors.PURPLE),
        ]
        stat_grid = ft.GridView(expand=False, max_extent=160, child_aspect_ratio=1.5, spacing=10, run_spacing=10, controls=[
            self.card(ft.Column(tight=True, spacing=7, controls=[ft.Icon(icon, color=color), ft.Text(value, weight=ft.FontWeight.BOLD), ft.Text(label, size=12, color=ft.Colors.BLUE_GREY_600)]), padding=12)
            for label, value, icon, color in stats
        ])
        daily_values = {row["day"]: row["minutes"] for row in db.minutes_per_day(7)}
        days = [now.fromordinal(now.toordinal() - offset) for offset in range(6, -1, -1)]
        points = [fc.LineChartDataPoint(x=index, y=daily_values.get(day.isoformat(), 0) / 60) for index, day in enumerate(days)]
        line_chart = fc.LineChart(
            data_series=[fc.LineChartData(points=points, color=ft.Colors.INDIGO, stroke_width=4, curved=True,
                above_line_bgcolor=ft.Colors.with_opacity(0.14, ft.Colors.INDIGO), point=True)],
            min_x=0, max_x=6, min_y=0, max_y=max(1, max((point.y for point in points), default=0)), height=220,
        )
        subject_data = [row for row in subjects if row["minutes"] > 0]
        pie_chart = fc.PieChart(
            sections=[fc.PieChartSection(value=row["minutes"], color=subject_color(row["color"]), title=row["name"], radius=62) for row in subject_data],
            center_space_radius=30, sections_space=3, height=220,
        ) if subject_data else ft.Container(height=80, alignment=ft.Alignment.CENTER, content=ft.Text("ستظهر هنا بياناتك بعد أول جلسة."))
        bar_items = [row for row in subjects if row["sessions"] > 0]
        bar_chart = fc.BarChart(
            groups=[fc.BarChartGroup(x=index, rods=[fc.BarChartRod(to_y=row["sessions"], color=subject_color(row["color"]), width=22, border_radius=ft.BorderRadius.all(8))]) for index, row in enumerate(bar_items)],
            max_y=max(1, max((row["sessions"] for row in bar_items), default=0)), height=220,
        ) if bar_items else ft.Container(height=80, alignment=ft.Alignment.CENTER, content=ft.Text("لا توجد جلسات مسجلة بعد."))
        table_rows = [ft.DataRow(cells=[
            ft.DataCell(ft.Text(row["name"])), ft.DataCell(ft.Text(format_minutes(row["minutes"]))), ft.DataCell(ft.Text(str(row["sessions"]))),
        ]) for row in subjects]
        table = ft.DataTable(
            columns=[ft.DataColumn(label=ft.Text("المادة")), ft.DataColumn(label=ft.Text("الوقت")), ft.DataColumn(label=ft.Text("الجلسات"))],
            rows=table_rows,
        ) if table_rows else ft.Text("أضف مادة ثم احفظ جلسة مذاكرة لتظهر التفاصيل.", color=ft.Colors.BLUE_GREY_600)
        last_sessions = [ft.ListTile(
            title=ft.Text(row.get("subject_name") or "جلسة عامة"),
            subtitle=ft.Text(f"{row['started_at'][:16].replace('T', ' ')} · {row['session_type']}"),
            trailing=ft.Text(format_minutes(row["minutes"])), leading=ft.Icon(ft.Icons.TIMER, color=ft.Colors.INDIGO),
        ) for row in sessions[:5]]
        controls = [self.header("إحصائياتك", "تابع تقدمك واكتشف أين يذهب وقتك"), stat_grid,
            self.card(ft.Column(tight=True, controls=[self.header("ساعات المذاكرة · آخر 7 أيام"), line_chart])),
            self.card(ft.Column(tight=True, controls=[self.header("توزيع الوقت حسب المادة"), pie_chart])),
            self.card(ft.Column(tight=True, controls=[self.header("عدد الجلسات لكل مادة"), bar_chart])),
            self.card(ft.Column(tight=True, controls=[self.header("ملخص المواد"), ft.Row(scroll=ft.ScrollMode.AUTO, controls=[table])])),
            self.card(ft.Column(tight=True, controls=[self.header("آخر الجلسات"), *(last_sessions or [ft.Text("لم تحفظ جلسة بعد.")])])),
        ]
        return ft.Column(expand=True, scroll=ft.ScrollMode.AUTO, spacing=14, controls=controls)

    def alarms_view(self):
        alarms = db.list_alarms()
        cards = []
        for alarm in alarms:
            cards.append(self.card(ft.Row(vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[
                ft.Icon(ft.Icons.ALARM, color=ft.Colors.ORANGE, size=30),
                ft.Column(expand=True, spacing=4, controls=[
                    ft.Text(alarm["label"], size=17, weight=ft.FontWeight.BOLD),
                    ft.Text(f"{alarm['time']} · {self.days_summary(alarm['days'])}", color=ft.Colors.BLUE_GREY_600),
                    ft.Text(alarm.get("subject_name") or "لا توجد مادة مرتبطة", size=12, color=ft.Colors.BLUE_GREY_500),
                ]),
                ft.Switch(value=bool(alarm["enabled"]), on_change=lambda e, aid=alarm["id"]: asyncio.create_task(self.toggle_alarm(aid, e.control.value))),
                ft.IconButton(icon=ft.Icons.DELETE_OUTLINE, tooltip="حذف", on_click=lambda e, aid=alarm["id"]: self.delete_alarm(aid)),
            ]), padding=12))
        return ft.Column(expand=True, spacing=12, controls=[
            ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN, controls=[self.header("منبهات المذاكرة", "تذكيرك يبدأ في وقته وتظل النغمة حتى تأكيدك"), self.primary_button("إضافة", ft.Icons.ADD, lambda: self.alarm_dialog())]),
            self.card(ft.Column(tight=True, spacing=8, controls=[
                ft.Row(controls=[ft.Icon(ft.Icons.INFO_OUTLINE, color=ft.Colors.INDIGO), ft.Text("لظهور الإشعار بعد إغلاق التطبيق، فعّلي إذن Android مرة واحدة.", expand=True, size=13)]),
                ft.Row(wrap=True, controls=[
                    self.primary_button("تفعيل الإذن وجدولة الإشعارات", ft.Icons.NOTIFICATIONS_ACTIVE, self.enable_background_notifications),
                    self.primary_button("اختبار صوت المنبه", ft.Icons.VOLUME_UP, self.test_alarm_sound, color=ft.Colors.GREEN),
                ]),
            ])),
            ft.Column(expand=True, scroll=ft.ScrollMode.AUTO, spacing=10, controls=cards or [self.card(ft.Text("لم تضف منبهات بعد. أنشئ تذكيراً لجلسة مذاكرة قادمة."))]),
        ])

    @staticmethod
    def days_summary(days: str) -> str:
        if days == "all":
            return "كل يوم"
        names = ["اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت", "أحد"]
        return "، ".join(names[int(index)] for index in days.split(",") if index.isdigit() and int(index) < 7)

    def alarm_dialog(self):
        label = self.text_field("اسم المنبه", value="موعد مذاكرة")
        time_field = self.text_field("الوقت بنظام 24 ساعة", value="18:00", hint="ساعة:دقيقة")
        subjects = db.list_subjects()
        subject_items = [{"id": None, "label": "بدون مادة"}] + [{"id": s["id"], "label": subject_label(s)} for s in subjects]
        subject = ft.Dropdown(label="المادة المرتبطة (اختياري)", value="بدون مادة", options=[option_for(item["label"]) for item in subject_items])
        all_days = ft.Checkbox(label="كل يوم", value=True)
        weekday_checks = [ft.Checkbox(label=name, value=False) for name in ("الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")]
        ringtone = ft.Dropdown(label="نغمة الرنين", value="نغمة هادئة", options=[option_for("نغمة هادئة"), option_for("نغمة حادة"), option_for("ملف صوتي مخصص")])
        chosen_file = {"path": ""}
        file_label = ft.Text("استخدم نغمة داخلية أو اختر ملف صوت من جهازك.", size=12, color=ft.Colors.BLUE_GREY_600)
        async def pick_ringtone():
            if self.page.web:
                self.notify("اختيار ملفات الجهاز متاح في نسخة التطبيق المثبتة.", ft.Colors.ORANGE)
                return
            files = await self.file_picker.pick_files(dialog_title="اختر نغمة صوتية", allowed_extensions=["wav", "mp3", "ogg", "m4a"], allow_multiple=False, with_data=True)
            if files:
                try:
                    selected_file = files[0]
                    audio_data = selected_file.bytes
                    if audio_data is None and selected_file.path:
                        with open(selected_file.path, "rb") as source:
                            audio_data = source.read()
                    if not audio_data:
                        raise ValueError("لم يتمكن منتقي الملفات من قراءة محتوى الصوت")
                    root = os.path.join(db.data_directory(), "ringtones")
                    os.makedirs(root, exist_ok=True)
                    name = os.path.basename(selected_file.name)
                    destination = os.path.join(root, name)
                    with open(destination, "wb") as target:
                        target.write(audio_data)
                    chosen_file["path"] = destination
                    file_label.value = f"تم استيراد النغمة: {name} · محفوظة داخل التطبيق"
                    file_label.update()
                    if not await self.alarm_manager.preview_sound(destination):
                        file_label.value += " · تعذر تشغيلها؛ جربي WAV أو MP3"
                        file_label.update()
                except Exception:
                    log.exception("ringtone import failed")
                    file_label.value = "تعذر استيراد الصوت. اختاري ملف WAV أو MP3 أصغر حجماً."
                    file_label.update()
        async def save():
            title = (label.value or "").strip()
            time_value = (time_field.value or "").strip()
            try:
                datetime.strptime(time_value, "%H:%M")
            except ValueError:
                self.notify("أدخل الوقت بصيغة 24 ساعة، مثل 18:30.", ft.Colors.RED)
                return
            if not title:
                self.notify("اكتب اسماً للمنبه.", ft.Colors.RED)
                return
            if all_days.value:
                days = "all"
            else:
                selected = [str(index) for index, box in enumerate(weekday_checks) if box.value]
                if not selected:
                    self.notify("اختر يوماً واحداً على الأقل.", ft.Colors.RED)
                    return
                days = ",".join(selected)
            subject_id = next((item["id"] for item in subject_items if item["label"] == subject.value), None)
            tone = chosen_file["path"] if chosen_file["path"] else ("نغمة هادئة" if ringtone.value == "ملف صوتي مخصص" else ringtone.value or "نغمة هادئة")
            db.save_alarm(title, time_value, days, tone, subject_id)
            self.page.pop_dialog()
            is_android = not self.page.web and "android" in str(self.page.platform).lower()
            if is_android and db.get_setting("background_notifications_enabled", "0") != "1":
                synced = await self._request_and_schedule_android_notifications()
            else:
                synced = await self.sync_notifications(show_feedback=False)
            self.render("alarms")
            if is_android and not synced:
                self.notify("حُفظ المنبه، لكن لم يكتمل إذن إشعار الخلفية. افتحي الإعدادات واسمحي بالإشعارات والتنبيهات الدقيقة.", ft.Colors.ORANGE)
            elif is_android:
                self.notify("حُفظ المنبه وجُدول إشعاره حتى مع إغلاق التطبيق.", ft.Colors.GREEN)
            else:
                self.notify("تم حفظ المنبه.", ft.Colors.GREEN)
        self.page.show_dialog(ft.AlertDialog(
            modal=True, title=ft.Text("إضافة منبه مذاكرة"), scrollable=True,
            content=ft.Column(tight=True, spacing=10, controls=[
                label, time_field, subject, ringtone, ft.TextButton("اختيار نغمة من الجهاز", icon=ft.Icons.UPLOAD_FILE, on_click=pick_ringtone), file_label,
                all_days, ft.Row(wrap=True, controls=weekday_checks),
            ]),
            actions=[ft.TextButton("إلغاء", on_click=lambda: self.page.pop_dialog()), self.primary_button("حفظ المنبه", ft.Icons.CHECK, save)],
        ))

    async def show_alarm(self, alarm: dict):
        if self.active_alarm is not None:
            return
        self.active_alarm = alarm
        await self.alarm_manager.ring(alarm)
        subject = alarm.get("subject_name") or ""
        def start_study():
            self.active_alarm = None
            self.page.pop_dialog()
            asyncio.create_task(self.alarm_manager.stop_ringing())
            self.pomodoro_subject = alarm.get("subject_id")
            self.pomodoro_minutes = 25
            self.remaining_seconds = 25 * 60
            self.render("pomodoro")
            asyncio.create_task(self.start_timer())
        async def studied():
            quick_minutes = 5
            try:
                quick_minutes = max(1, int(db.get_setting("quick_session_minutes", "5")))
            except ValueError:
                pass
            db.add_session(alarm.get("subject_id"), quick_minutes, "quick")
            self.active_alarm = None
            self.page.pop_dialog()
            await self.alarm_manager.stop_ringing()
            self.render("home")
            self.notify(f"تم تسجيل {quick_minutes} دقائق مذاكرة سريعة. أحسنت!", ft.Colors.GREEN)
        alarm_dialog = ft.AlertDialog(
            modal=True,
            barrier_color=ft.Colors.with_opacity(0.88, ft.Colors.BLACK),
            title=ft.Text("حان وقت المذاكرة!", size=24, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
            content=ft.Column(tight=True, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=12, controls=[
                ft.Icon(ft.Icons.ALARM, size=64, color=ft.Colors.ORANGE),
                ft.Text(alarm["label"], size=20, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
                ft.Text(f"{alarm['time']}" + (f" · {subject}" if subject else ""), text_align=ft.TextAlign.CENTER, color=ft.Colors.BLUE_GREY_600),
                ft.Text("لن تتوقف النغمة حتى تؤكد بدء المذاكرة أو أنك ذاكرت بالفعل.", text_align=ft.TextAlign.CENTER),
            ]),
            actions=[self.primary_button("لقد ذاكرت", ft.Icons.CHECK_CIRCLE, studied, color=ft.Colors.GREEN),
                     self.primary_button("ابدأ المذاكرة الآن", ft.Icons.PLAY_ARROW, start_study)],
            actions_alignment=ft.MainAxisAlignment.CENTER,
            inset_padding=ft.Padding.symmetric(horizontal=18, vertical=24),
        )
        self.page.show_dialog(alarm_dialog)

    async def toggle_alarm(self, alarm_id: int, enabled: bool):
        db.set_alarm_enabled(alarm_id, enabled)
        await self.sync_notifications(show_feedback=False)
        self.render("alarms")
        self.notify("تم تفعيل المنبه." if enabled else "تم إيقاف المنبه مؤقتاً.")

    def delete_alarm(self, alarm_id: int):
        async def remove():
            db.delete_alarm(alarm_id)
            self.page.pop_dialog()
            await self.sync_notifications(show_feedback=False)
            self.render("alarms")
            self.notify("تم حذف المنبه.")
        self.page.show_dialog(ft.AlertDialog(modal=True, title=ft.Text("حذف المنبه؟"),
            actions=[ft.TextButton("إلغاء", on_click=lambda: self.page.pop_dialog()), ft.TextButton("حذف", on_click=remove)]))

    def settings_view(self):
        goals = db.get_goals()
        daily = self.text_field("الهدف اليومي بالدقائق", value=str(goals["target_minutes_daily"]), number=True)
        weekly = self.text_field("الهدف الأسبوعي بالدقائق", value=str(goals["target_minutes_weekly"]), number=True)
        quick = self.text_field("مدة جلسة التأكيد السريعة بالدقائق", value=db.get_setting("quick_session_minutes", "5"), number=True)
        def save_settings():
            try:
                daily_value, weekly_value, quick_value = int(daily.value), int(weekly.value), int(quick.value)
                if min(daily_value, weekly_value, quick_value) < 1:
                    raise ValueError
            except (TypeError, ValueError):
                self.notify("أدخل أرقاماً صحيحة أكبر من صفر.", ft.Colors.RED)
                return
            db.set_goals(daily_value, weekly_value)
            db.set_setting("quick_session_minutes", str(quick_value))
            self.notify("تم حفظ الأهداف والإعدادات.", ft.Colors.GREEN)
            self.render("settings")
        def export_db():
            async def do_export():
                if self.page.web:
                    self.notify("تصدير قاعدة البيانات متاح في التطبيق المثبت.", ft.Colors.ORANGE)
                    return
                try:
                    data = db.export_bytes()
                    path = await self.file_picker.save_file(dialog_title="تصدير قاعدة البيانات", file_name="yalla-qom-zaker-backup.sqlite3", src_bytes=data)
                    if path:
                        self.notify("تم تصدير النسخة الاحتياطية.", ft.Colors.GREEN)
                except Exception:
                    log.exception("database export failed")
                    self.notify("تعذر تصدير قاعدة البيانات.", ft.Colors.RED)
            asyncio.create_task(do_export())
        def import_db():
            async def do_import():
                if self.page.web:
                    self.notify("استيراد قاعدة البيانات متاح في التطبيق المثبت.", ft.Colors.ORANGE)
                    return
                files = await self.file_picker.pick_files(dialog_title="استيراد نسخة احتياطية", allowed_extensions=["sqlite3", "db"], allow_multiple=False)
                if not files:
                    return
                try:
                    db.import_database(files[0].path)
                    self.notify("تم استيراد قاعدة البيانات. أعد تشغيل التطبيق لتحديث كل البيانات.", ft.Colors.GREEN)
                    self.render("home")
                except Exception as exc:
                    log.exception("database import failed")
                    self.notify(str(exc), ft.Colors.RED)
            asyncio.create_task(do_import())
        android_notifications_available = not self.page.web and "android" in str(self.page.platform).lower()
        return ft.Column(expand=True, scroll=ft.ScrollMode.AUTO, spacing=14, controls=[
            self.header("الإعدادات", "خصص أهدافك وطريقة استخدام التطبيق"),
            self.card(ft.Column(tight=True, spacing=10, controls=[
                self.header("إشعارات المنبهات في الخلفية"),
                ft.Text("عند حفظ أول منبه على Android سيظهر طلب إذن الإشعارات. تُجدول الإشعارات لمدة 30 يوماً قادمة ثم تُحدّث عند فتح التطبيق.", color=ft.Colors.BLUE_GREY_600),
                self.primary_button("طلب الإذن الآن وجدولة المنبهات", ft.Icons.NOTIFICATIONS_ACTIVE, self.enable_background_notifications, color=ft.Colors.INDIGO),
                ft.Text("مكان الأذونات يدوياً: إعدادات الهاتف ← التطبيقات ← يلا قوم ذاكر ← الإشعارات ← السماح. وللتنبيه الدقيق: الوصول الخاص للتطبيقات ← المنبهات والتذكيرات ← يلا قوم ذاكر ← السماح.", size=12, color=ft.Colors.ORANGE),
                ft.Text("الإشعارات المجدولة: " + ("مفعّلة" if db.get_setting("background_notifications_enabled", "0") == "1" else "غير مفعّلة"), size=12, color=ft.Colors.GREEN if db.get_setting("background_notifications_enabled", "0") == "1" else ft.Colors.BLUE_GREY_600),
                ft.Text("هذا الإعداد مخصص لتطبيق Android المثبت." if not android_notifications_available else "بعد السماح، اضبط إذن التنبيهات الدقيقة في Android إذا طلبه جهازك.", size=12, color=ft.Colors.ORANGE),
            ])),
            self.card(ft.Column(tight=True, spacing=10, controls=[
                self.header("اختبار الصوت"),
                ft.Text("شغّلي نغمة قصيرة للتأكد من أن صوت الوسائط يعمل على الجهاز.", color=ft.Colors.BLUE_GREY_600),
                self.primary_button("تشغيل صوت تجريبي", ft.Icons.VOLUME_UP, self.test_alarm_sound, color=ft.Colors.GREEN),
            ])),
            self.card(ft.Column(tight=True, spacing=12, controls=[
                self.header("أهداف المذاكرة"), daily, weekly, quick,
                self.primary_button("حفظ الإعدادات", ft.Icons.CHECK, save_settings),
            ])),
            self.card(ft.Column(tight=True, spacing=10, controls=[
                self.header("النسخ الاحتياطي"),
                ft.Text("صدّر بيانات SQLite للاحتفاظ بنسخة، أو استورد نسخة موجودة.", color=ft.Colors.BLUE_GREY_600),
                ft.Row(wrap=True, controls=[
                    ft.OutlinedButton(content="تصدير قاعدة البيانات", icon=ft.Icons.FILE_DOWNLOAD, on_click=export_db),
                    ft.OutlinedButton(content="استيراد نسخة", icon=ft.Icons.UPLOAD_FILE, on_click=import_db),
                ]),
            ])),
            self.card(ft.Row(controls=[ft.Icon(ft.Icons.PHONE_ANDROID, color=ft.Colors.INDIGO), ft.Text("البيانات محفوظة محلياً على جهازك، ولا يحتاج التطبيق إلى اتصال بالإنترنت.", expand=True)])),
            self.card(ft.Text("تنبيه: الإشعارات المجدولة تعمل على Android بعد منح الإذن. قد تتطلب الأجهزة السماح بالتنبيهات الدقيقة وتعطيل قيود البطارية؛ ولا يمكن للنظام ضمان تشغيل نافذة التطبيق أو نغمة مخصصة متكررة بعد إغلاقه بالقوة.", size=12, color=ft.Colors.BLUE_GREY_600)),
        ])


async def main(page: ft.Page):
    if not page.web:
        try:
            storage_paths = ft.StoragePaths()
            support_directory = await storage_paths.get_application_support_directory()
            db.set_database_directory(support_directory)
        except Exception:
            # database._connect() will fall back to a writable temporary folder if needed.
            log.exception("could not resolve Flet's app-private database directory")
    app = StudyApp(page)
    await app.start()


ft.run(main)
