"""Small date, duration, and display helpers."""
from __future__ import annotations

from datetime import date, datetime, timedelta


WEEKDAYS_AR = ["الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"]


def today_iso() -> str:
    return date.today().isoformat()


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def format_minutes(minutes: int) -> str:
    minutes = max(0, int(minutes))
    hours, remainder = divmod(minutes, 60)
    if hours and remainder:
        return f"{hours} س {remainder} د"
    if hours:
        return f"{hours} ساعة" if hours == 1 else f"{hours} ساعات"
    return f"{remainder} دقيقة"


def week_bounds(anchor: date | None = None) -> tuple[str, str]:
    anchor = anchor or date.today()
    start = anchor - timedelta(days=anchor.weekday())
    end = start + timedelta(days=6)
    return start.isoformat(), end.isoformat()


def month_bounds(anchor: date | None = None) -> tuple[str, str]:
    anchor = anchor or date.today()
    start = anchor.replace(day=1)
    if anchor.month == 12:
        next_month = date(anchor.year + 1, 1, 1)
    else:
        next_month = date(anchor.year, anchor.month + 1, 1)
    return start.isoformat(), (next_month - timedelta(days=1)).isoformat()


def weekday_label(day_index: int) -> str:
    return WEEKDAYS_AR[day_index % 7]


def parse_alarm_days(value: str) -> set[int] | None:
    if value == "all":
        return None
    try:
        return {int(day) for day in value.split(",") if day.strip()}
    except ValueError:
        return None


def alarm_matches_today(days: str, weekday: int) -> bool:
    selected = parse_alarm_days(days)
    return selected is None or weekday in selected
